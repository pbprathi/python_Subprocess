from autopy.packageinstall import Mainclass

def main():
    p1=Mainclass()
    p1.start()


if __name__=='__main__':
    main()
